# ADR-001: Embedding Model — BGE-M3 vs OpenAI text-embedding-3-small

**Date:** 2026-04-21
**Status:** Accepted

## Context

System requires embedding Traditional Chinese legal text (條文). Users query in colloquial Mandarin. Full local deployment required — no data leaves the machine.

## Decision

Use BAAI/bge-m3 running locally via FlagEmbedding.

## Consequences

**Positive:**
- State-of-the-art Chinese text understanding
- Supports dense + sparse + ColBERT in one model
- Zero API cost; data stays on-premise
- 1024-dim dense vectors align with pgvector performance sweet spot

**Negative:**
- ~2GB model download on first run
- CPU inference ~3–5 seconds per batch; GPU recommended for production latency target

## Rejected Alternatives

**OpenAI text-embedding-3-small:** API cost accumulates at scale; data sent to external servers; slightly weaker on Traditional Chinese legal terminology.
