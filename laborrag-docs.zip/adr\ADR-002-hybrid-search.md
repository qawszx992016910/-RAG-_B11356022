# ADR-002: Hybrid Search (Dense + Sparse) vs Pure Vector RAG

**Date:** 2026-04-21
**Status:** Accepted

## Context

Labor law users query in two distinct patterns:
1. Semantic: "老闆可以隨便開除我嗎" (no article numbers)
2. Lexical: "第24條加班費" or "資遣費" (exact legal terms)

Pure vector search misses high-precision lexical matches. Pure keyword search misses semantic paraphrases.

## Decision

Hybrid: pgvector cosine (dense) + PostgreSQL tsvector BM25 (sparse), fused via Reciprocal Rank Fusion (RRF, k=60).

RRF formula: `score(d) = Σ 1/(k + rank_i(d))`

## Consequences

**Positive:**
- Single retrieval pass covers both query types
- tsvector index is native PostgreSQL — no additional service
- RRF is parameter-light (only k to tune)

**Negative:**
- Two index maintenance overhead
- RRF k=60 is a heuristic; may need tuning for domain

## Rejected Alternatives

**Pure Vector RAG:** Exact article number queries ("第24條") scored poorly — bi-encoder struggles with short numeric identifiers.
