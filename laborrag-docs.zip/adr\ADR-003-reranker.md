# ADR-003: Cross-Encoder Reranker Intervention Point

**Date:** 2026-04-21
**Status:** Accepted

## Context

Bi-encoder retrieval (BGE-M3 dense + BM25 sparse) is fast but imprecise — Top-20 candidates contain irrelevant articles. Feeding all 20 to the LLM wastes context tokens and degrades answer quality.

## Decision

After RRF fusion, apply BGE-Reranker-v2-m3 (cross-encoder) to Top-20 candidates. Retain Top-5 for LLM context.

Intervention point: `src/laborrag/retrieval/reranker.py`, called in `cli.py:query()` after fusion, before `generate_answer()`.

## Consequences

**Positive:**
- Cross-encoder jointly encodes query+candidate → higher precision than bi-encoder
- Rerank score is interpretable (0–1 after normalization) → explainability artifact
- LLM receives 5 focused articles instead of 20 noisy ones

**Negative:**
- Additional inference pass (~200–400ms on CPU)
- Must instantiate reranker model separately from embedder

## Rejected Alternatives

**Direct Top-5 from RRF:** Bi-encoder recall at Top-5 is ~65% on golden set vs ~85% after reranking. Gap too large for a legal advisory system.
