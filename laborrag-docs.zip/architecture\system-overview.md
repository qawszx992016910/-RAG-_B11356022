# LaborRAG System Architecture

## Data Flow

```
[laws.moj.gov.tw XML API]
        ↓ ETL: src/laborrag/etl/
[KnowledgeAtom JSON]  ←── JSON Schema (schemas/knowledge_atom.json)
        ↓ BGE-M3 Embedding: src/laborrag/embed/
[PostgreSQL + pgvector]
  ├── vector(1024) index (ivfflat, cosine)
  └── TSVECTOR index (GIN, BM25)
        ↓
┌─────────────────────────────────────────┐
│           Retrieval Layer               │
│  src/laborrag/retrieval/                │
│                                         │
│  dense.py  →  pgvector cosine  ──┐      │
│                                  ├─ RRF fusion.py → Top-20
│  sparse.py →  tsvector BM25  ───┘      │
│                                         │
│  reranker.py (BGE-Reranker-v2-m3)       │
│       Top-20 → cross-encoder → Top-5   │
└────────────────┬────────────────────────┘
                 ↓  5 articles + content
     src/laborrag/generation/generator.py
     [Ollama Llama3.1-8B]
                 ↓
     Structured answer + article citations
```

## ETL Boundary

Non-structured XML → Structured KnowledgeAtom (Pydantic) → pgvector embeddings

Vectorization boundary: `src/laborrag/embed/embedder.py`
- Input: raw text string
- Output: float[1024] (BGE-M3 dense vector)

## Reranking Intervention Point

After RRF fusion produces Top-20 candidates, before LLM call.

- File: `src/laborrag/retrieval/reranker.py`
- Input: `(query, [(atom_id, content)]) × 20`
- Output: `[(atom_id, rerank_score)] × 5`

## Component Responsibilities

| File | Responsibility |
|------|---------------|
| `etl/fetch.py` | HTTP fetch XML from laws.moj.gov.tw |
| `etl/parse.py` | XML → KnowledgeAtom list, keyword inference, parent-child split |
| `embed/embedder.py` | BGE-M3 text → float[1024] |
| `db/store.py` | Upsert atoms + vectors into PostgreSQL |
| `retrieval/dense.py` | pgvector cosine similarity search |
| `retrieval/sparse.py` | tsvector BM25 full-text search |
| `retrieval/fusion.py` | RRF merge of dense + sparse results |
| `retrieval/reranker.py` | BGE-Reranker cross-encoder reranking |
| `generation/generator.py` | Ollama LLM with grounding prompt |
| `cli.py` | CLI: ingest / query / eval |
